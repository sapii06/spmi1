

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="row">
                                <div class="col-sm-6 col-lg-6">
                                    <div class="card-body card-widget">
                                        <div class="media">
                                            <span class="card-widget__icon text-primary"><i class="icon-globe-alt"></i></span>
                                            <div class="media-body">
                                                <h2 class="card-widget__title"><?php echo $prodi; ?></h2>
                                                <h5 class="card-widget__subtitle">Program Studi</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
            
                                <div class="col-sm-6 col-lg-6 border-left">
                                    <div class="card-body card-widget">
                                        <div class="media">
                                            <span class="card-widget__icon text-warning"><i class="icon-grid"></i></span>
                                            <div class="media-body">
                                                <h2 class="card-widget__title"><?php echo $makul; ?></h2>
                                                <h5 class="card-widget__subtitle">Mata Kuliah</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
            
                                
                            </div>
                        </div>
                    </div>
                </div>           
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        