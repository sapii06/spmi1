<div class="footer">
            <!-- <div class="copyright">
                <p>Copyright &copy; <?php echo date('Y') ?></p>
            </div> -->
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="assets/plugins/common/common.min.js"></script>
    <script src="assets/js/custom.min.js"></script>
    <script src="assets/js/settings.js"></script>
    <script src="assets/js/gleek.js"></script>
    <script src="assets/js/styleSwitcher.js"></script>

    <script src="assets/plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="assets/plugins/tables/js/datatable-init/datatable-basic.min.js"></script>

    <script src="assets/plugins/chart.js/Chart.bundle.min.js"></script>
    <script src="assets/plugins/raphael/raphael.min.js"></script>
    <script src="assets/plugins/morris/morris.min.js"></script>
    <script src="assets/plugins/weather/js/jquery.simpleWeather.min.js"></script>
    <script src="assets/plugins/weather/js/weather-init.js"></script>
    <script src="assets/js/dashboard/dashboard-2.js"></script>
    <script>
        function goBack() {
            window.history.back();
        }
    </script>

</body>


</html>