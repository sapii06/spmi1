
        <!-- Quote/testimonial aside-->
        <aside class="text-center bg-gradient-primary-to-secondary">
            <div class="container px-5">
                <div class="row gx-5 justify-content-center">
                    <div class="col-xl-8">
                        <div class="h2 fs-1 text-white mb-4">"Bantu kami untuk selalu meningkatkan pelayanan di Universitas Qamarul Huda Badaruddin dengan mengisi kuesioner secara online."</div>
                    </div>
                </div>
            </div>
        </aside>
        
